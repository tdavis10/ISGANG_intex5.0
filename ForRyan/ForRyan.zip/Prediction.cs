﻿using System;
namespace AuthLab2_RyanPinkney
{
    public class Prediction
    {

        public string PredictedValue { get; set; }



    }
}
